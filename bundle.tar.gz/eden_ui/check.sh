echo "0;3;A" >> log.txt
sleep 4
echo "1;3;B" >> log.txt
sleep 4
echo "2;3;C" >> log.txt
sleep 4
echo "3;3;check passed" >> log.txt
rm -rf lock.txt
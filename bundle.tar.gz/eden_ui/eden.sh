echo "0;3;align" >> log.txt
sleep 4
echo "1;3;stuff" >> log.txt
sleep 4
echo "2;3;bla" >> log.txt
sleep 4
echo "3;3;dnds finished" >> log.txt
rm -rf lock.txt
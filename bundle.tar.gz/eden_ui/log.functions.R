
# ==============================================================================================
# procedure to update log file / progress message
# ==============================================================================================

# progress bar gets updated based on the log file. Log file must be in csv format. 
# First column=int(current_step); second column=int(max_steps); third column=str(step_description)
# progess bar will be closed when a closing or error signal is on the log file (log file produced by the shell functions executed by checkbutton/startbutton)

# there was some mysterious bug that the progess bar cannot be closed appropriate which caused some troble with the new progress bar which will be created with the startbutton
# thus, we have here two seperate progress bar obj. 


# update the progress bar for check routine
#updateProgressCheck <- function(value = NULL, detail = NULL) {
#  if (is.null(value)) {
#    value <- progress_check$getValue()
#    value <- value + (progress$getMax() - value) / 5
#  }
#  progress_check$set(value = value, detail = detail)
#}

# loads the log file and extract the informations for the check process bar
get_new_log <- function() {
  msg <- ""
  data <- read.table(log.path, header = F, sep = ";")
  colnames(data) <- c("step", "steps", "message")
  
  last_event <- data[nrow(data),]$message # current message
  steps<-data[nrow(data),]$steps # current step 
  step<-data[nrow(data),]$step # total number of steps till finished
  print(last_event) # for debugging, print the last event
  if (last_event == "error" && isolate(status$progessbar_check_open)){ # error signal
    progress_check$close()
    status$progessbar_check_open <- FALSE
    status$check_failed <<- TRUE
    msg <-  paste("<span class='label label-danger'>Error</span>")
  } else if (last_event == "check passed" && isolate(status$progessbar_check_open)){ # finished signal
    msg <- paste("<span class='label label-danger'>check passed", step, "</span>")
    status$checkpassed <- TRUE
    progress_check$close()
    status$progessbar_check_open <- FALSE
  } else if (isolate(status$progessbar_check_open)){
    msg <- paste("<span class='label label-danger'>check running", step, "</span>")
    # detect if there is a new step, and update progressbar
    if (status$check_event != last_event){
      progress_check$inc(1/steps, detail = last_event)
      status$check_event <- last_event # update event
    }
  }
  return(NULL)
  #   return(msg)
}

# loads the log file and extract the informations for the eden progress bar
get_new_log_eden <- function() {
  msg <- ""
  data <- read.table(log.path, header = F, sep = ";")
  colnames(data) <- c("step", "steps", "message")
  last_event <- data[nrow(data),]$message # current message
  steps <- data[nrow(data),]$steps # current step 
  step <- data[nrow(data),]$step # total number of steps till finished
  print(last_event) # for debugging, print the last event
  if (last_event == "error" && isolate(status$progessbar_eden_open)){ # error signal
    progress_eden$close()
    status$progessbar_eden_open <- FALSE
    status$eden_failed <<- TRUE
    msg <-  paste("<span class='label label-danger'>Error: Eden failed</span>")
  } else if (last_event == "eden finished" && isolate(status$progessbar_eden_open)){ # finished signal
    msg <- paste("<span class='label label-danger'>eden finished passed", step, "</span>")
    status$eden_finished <- TRUE
    progress_eden$close()
    status$progessbar_eden_open <- FALSE
  } else if (isolate(status$progessbar_eden_open)){
    msg <- paste("<span class='label label-danger'>eden running", step, "</span>")
    # detect if there is a new step, and update progressbar
    if (status$eden_event != last_event){
      progress_eden$inc(1/steps, detail = last_event)
      status$eden_event <- last_event # update event
    }
  }
  # return(msg)
}

# Initialize log
my_log <<- get_new_log()

# Initialize log
my_log_eden <<- get_new_log_eden()

# Function to update my_data
update_log <- function() {
  my_log <<- get_new_log()
}

# Function to update my_data
update_log_eden <- function() {
  my_log_eden <<- get_new_log_eden()
}

output$log = renderText({
  if(status$progessbar_check_open){
    invalidateLater(millis = 1000, session)
    update_log()
  } 
})

output$log_eden = renderText({
  if(status$progessbar_eden_open){
    invalidateLater(millis = 1000, session)
    update_log_eden()
  }
})





